##### InSlimVML v0.1.0
#### SlimVML Author ThePapanoob
### InSlim Fork By PJninja
## Using Unity Doorstop Embedding
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

InSlim VML is a very basic and very barebones .dll splicing tool for modding
Unity packaged games. It's main use is when tied with Harmony 2.0 to make
drastic changes to game code. SlimVML is a branch redit of Unity Doorstop 3.0.
InSlimVML is specifically designed with Valheim in mind.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
PACKAGED LIBRARIES
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Harmony v2.0.4 by pardeike
Vale-UI-Library v0.1.0 by PJninja
Vale-Valheim-Library v0.1.1 by PJninja
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
CHANGELOG
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Feb 17 2021 - v0.1.0
	+ Inital Branch Off From SlimVML
	+ InSlimVML Core Edits and Build

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Discord Help Link : https://discord.gg/ZW8raU68Em
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++